/*






*/

#ifndef baseVERSION_H
#define baseVERSION_H

#include <QVersionNumber>


static QString baseVersionString("0.6.2");
static QVersionNumber baseVersion = QVersionNumber::fromString(baseVersionString);


#endif // baseVERSION_H
