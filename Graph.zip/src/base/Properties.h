/*






*/

#pragma once


enum PropertiesID
{
	ITEM_ID = 0,	// unique id of an item (text/int)
	ITEM_LABEL,		// label of an item (arbitrary text)
	ITEM_COMMENT,	// any additional text 
	
	ID_USER = 1000	// user-defined properties
};
