/********************************************************************************
** Form generated from reading UI file 'CGraphEditorUI.ui'
**
** Created by: Qt User Interface Compiler version 5.14.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CGRAPHEDITORUI_H
#define UI_CGRAPHEDITORUI_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CGraphEditorUI
{
public:
    QPushButton *BFSpushButton;
    QPushButton *DFSpushButton;
    QPushButton *PrimpushButton;
    QPushButton *pushButton;
    QPushButton *DjpushButton;
    QPushButton *TopoButton;
    QPushButton *ResetpushButton;

    void setupUi(QWidget *CGraphEditorUI)
    {
        if (CGraphEditorUI->objectName().isEmpty())
            CGraphEditorUI->setObjectName(QString::fromUtf8("CGraphEditorUI"));
        CGraphEditorUI->resize(400, 300);
        BFSpushButton = new QPushButton(CGraphEditorUI);
        BFSpushButton->setObjectName(QString::fromUtf8("BFSpushButton"));
        BFSpushButton->setGeometry(QRect(80, 60, 112, 34));
        DFSpushButton = new QPushButton(CGraphEditorUI);
        DFSpushButton->setObjectName(QString::fromUtf8("DFSpushButton"));
        DFSpushButton->setGeometry(QRect(200, 60, 112, 34));
        PrimpushButton = new QPushButton(CGraphEditorUI);
        PrimpushButton->setObjectName(QString::fromUtf8("PrimpushButton"));
        PrimpushButton->setGeometry(QRect(80, 100, 112, 34));
        pushButton = new QPushButton(CGraphEditorUI);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(200, 100, 112, 34));
        DjpushButton = new QPushButton(CGraphEditorUI);
        DjpushButton->setObjectName(QString::fromUtf8("DjpushButton"));
        DjpushButton->setGeometry(QRect(80, 140, 112, 34));
        TopoButton = new QPushButton(CGraphEditorUI);
        TopoButton->setObjectName(QString::fromUtf8("TopoButton"));
        TopoButton->setGeometry(QRect(200, 140, 112, 34));
        ResetpushButton = new QPushButton(CGraphEditorUI);
        ResetpushButton->setObjectName(QString::fromUtf8("ResetpushButton"));
        ResetpushButton->setGeometry(QRect(80, 180, 231, 41));

        retranslateUi(CGraphEditorUI);
        QObject::connect(BFSpushButton, SIGNAL(clicked()), CGraphEditorUI, SLOT(on_bfs_btn_clicked()));
        QObject::connect(DFSpushButton, SIGNAL(clicked()), CGraphEditorUI, SLOT(on_dfs_btn_clicked()));
        QObject::connect(PrimpushButton, SIGNAL(clicked()), CGraphEditorUI, SLOT(on_prim_btn_clicked()));
        QObject::connect(pushButton, SIGNAL(clicked()), CGraphEditorUI, SLOT(on_kruskal_btn_clicked()));
        QObject::connect(DjpushButton, SIGNAL(clicked()), CGraphEditorUI, SLOT(on_dijkstra_btn_clicked()));
        QObject::connect(TopoButton, SIGNAL(clicked()), CGraphEditorUI, SLOT(on_topologicalSorting_btn_clicked()));
        QObject::connect(ResetpushButton, SIGNAL(clicked()), CGraphEditorUI, SLOT(on_reset_btn_clicked()));

        QMetaObject::connectSlotsByName(CGraphEditorUI);
    } // setupUi

    void retranslateUi(QWidget *CGraphEditorUI)
    {
        CGraphEditorUI->setWindowTitle(QCoreApplication::translate("CGraphEditorUI", "Form", nullptr));
        BFSpushButton->setText(QCoreApplication::translate("CGraphEditorUI", "BFS", nullptr));
        DFSpushButton->setText(QCoreApplication::translate("CGraphEditorUI", "DFS", nullptr));
        PrimpushButton->setText(QCoreApplication::translate("CGraphEditorUI", "Prim", nullptr));
        pushButton->setText(QCoreApplication::translate("CGraphEditorUI", "Kruskal", nullptr));
        DjpushButton->setText(QCoreApplication::translate("CGraphEditorUI", "Dijkstra", nullptr));
        TopoButton->setText(QCoreApplication::translate("CGraphEditorUI", "AOE", nullptr));
        ResetpushButton->setText(QCoreApplication::translate("CGraphEditorUI", "\351\207\215\347\275\256", nullptr));
    } // retranslateUi

};

namespace Ui {
    class CGraphEditorUI: public Ui_CGraphEditorUI {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CGRAPHEDITORUI_H
