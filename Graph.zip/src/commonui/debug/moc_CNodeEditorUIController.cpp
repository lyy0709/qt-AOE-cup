/****************************************************************************
** Meta object code from reading C++ file 'CNodeEditorUIController.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../CNodeEditorUIController.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'CNodeEditorUIController.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_CNodeEditorUIController_t {
    QByteArrayData data[44];
    char stringdata0[510];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CNodeEditorUIController_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CNodeEditorUIController_t qt_meta_stringdata_CNodeEditorUIController = {
    {
QT_MOC_LITERAL(0, 0, 23), // "CNodeEditorUIController"
QT_MOC_LITERAL(1, 24, 10), // "exportFile"
QT_MOC_LITERAL(2, 35, 0), // ""
QT_MOC_LITERAL(3, 36, 9), // "exportPDF"
QT_MOC_LITERAL(4, 46, 9), // "exportSVG"
QT_MOC_LITERAL(5, 56, 9), // "exportDOT"
QT_MOC_LITERAL(6, 66, 9), // "importCSV"
QT_MOC_LITERAL(7, 76, 8), // "fileName"
QT_MOC_LITERAL(8, 85, 8), // "QString*"
QT_MOC_LITERAL(9, 94, 9), // "lastError"
QT_MOC_LITERAL(10, 104, 8), // "doBackup"
QT_MOC_LITERAL(11, 113, 16), // "onNavigatorShown"
QT_MOC_LITERAL(12, 130, 18), // "onSelectionChanged"
QT_MOC_LITERAL(13, 149, 14), // "onSceneChanged"
QT_MOC_LITERAL(14, 164, 11), // "onSceneHint"
QT_MOC_LITERAL(15, 176, 4), // "text"
QT_MOC_LITERAL(16, 181, 20), // "onSceneStatusChanged"
QT_MOC_LITERAL(17, 202, 6), // "status"
QT_MOC_LITERAL(18, 209, 20), // "onSceneDoubleClicked"
QT_MOC_LITERAL(19, 230, 25), // "QGraphicsSceneMouseEvent*"
QT_MOC_LITERAL(20, 256, 10), // "mouseEvent"
QT_MOC_LITERAL(21, 267, 14), // "QGraphicsItem*"
QT_MOC_LITERAL(22, 282, 11), // "clickedItem"
QT_MOC_LITERAL(23, 294, 13), // "sceneEditMode"
QT_MOC_LITERAL(24, 308, 8), // "QAction*"
QT_MOC_LITERAL(25, 317, 17), // "onEditModeChanged"
QT_MOC_LITERAL(26, 335, 4), // "mode"
QT_MOC_LITERAL(27, 340, 13), // "onZoomChanged"
QT_MOC_LITERAL(28, 354, 11), // "currentZoom"
QT_MOC_LITERAL(29, 366, 4), // "zoom"
QT_MOC_LITERAL(30, 371, 6), // "unzoom"
QT_MOC_LITERAL(31, 378, 9), // "resetZoom"
QT_MOC_LITERAL(32, 388, 12), // "sceneOptions"
QT_MOC_LITERAL(33, 401, 11), // "showNodeIds"
QT_MOC_LITERAL(34, 413, 2), // "on"
QT_MOC_LITERAL(35, 416, 11), // "showEdgeIds"
QT_MOC_LITERAL(36, 428, 4), // "undo"
QT_MOC_LITERAL(37, 433, 4), // "redo"
QT_MOC_LITERAL(38, 438, 12), // "changeItemId"
QT_MOC_LITERAL(39, 451, 11), // "addNodePort"
QT_MOC_LITERAL(40, 463, 12), // "editNodePort"
QT_MOC_LITERAL(41, 476, 11), // "factorNodes"
QT_MOC_LITERAL(42, 488, 4), // "find"
QT_MOC_LITERAL(43, 493, 16) // "onLayoutFinished"

    },
    "CNodeEditorUIController\0exportFile\0\0"
    "exportPDF\0exportSVG\0exportDOT\0importCSV\0"
    "fileName\0QString*\0lastError\0doBackup\0"
    "onNavigatorShown\0onSelectionChanged\0"
    "onSceneChanged\0onSceneHint\0text\0"
    "onSceneStatusChanged\0status\0"
    "onSceneDoubleClicked\0QGraphicsSceneMouseEvent*\0"
    "mouseEvent\0QGraphicsItem*\0clickedItem\0"
    "sceneEditMode\0QAction*\0onEditModeChanged\0"
    "mode\0onZoomChanged\0currentZoom\0zoom\0"
    "unzoom\0resetZoom\0sceneOptions\0showNodeIds\0"
    "on\0showEdgeIds\0undo\0redo\0changeItemId\0"
    "addNodePort\0editNodePort\0factorNodes\0"
    "find\0onLayoutFinished"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CNodeEditorUIController[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      29,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  159,    2, 0x08 /* Private */,
       3,    0,  160,    2, 0x08 /* Private */,
       4,    0,  161,    2, 0x08 /* Private */,
       5,    0,  162,    2, 0x08 /* Private */,
       6,    2,  163,    2, 0x08 /* Private */,
      10,    0,  168,    2, 0x08 /* Private */,
      11,    0,  169,    2, 0x08 /* Private */,
      12,    0,  170,    2, 0x08 /* Private */,
      13,    0,  171,    2, 0x08 /* Private */,
      14,    1,  172,    2, 0x08 /* Private */,
      16,    1,  175,    2, 0x08 /* Private */,
      18,    2,  178,    2, 0x08 /* Private */,
      23,    1,  183,    2, 0x08 /* Private */,
      25,    1,  186,    2, 0x08 /* Private */,
      27,    1,  189,    2, 0x08 /* Private */,
      29,    0,  192,    2, 0x08 /* Private */,
      30,    0,  193,    2, 0x08 /* Private */,
      31,    0,  194,    2, 0x08 /* Private */,
      32,    0,  195,    2, 0x08 /* Private */,
      33,    1,  196,    2, 0x08 /* Private */,
      35,    1,  199,    2, 0x08 /* Private */,
      36,    0,  202,    2, 0x08 /* Private */,
      37,    0,  203,    2, 0x08 /* Private */,
      38,    0,  204,    2, 0x08 /* Private */,
      39,    0,  205,    2, 0x08 /* Private */,
      40,    0,  206,    2, 0x08 /* Private */,
      41,    0,  207,    2, 0x08 /* Private */,
      42,    0,  208,    2, 0x08 /* Private */,
      43,    0,  209,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool, QMetaType::QString, 0x80000000 | 8,    7,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   15,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Void, 0x80000000 | 19, 0x80000000 | 21,   20,   22,
    QMetaType::Void, 0x80000000 | 24,    2,
    QMetaType::Void, QMetaType::Int,   26,
    QMetaType::Void, QMetaType::Double,   28,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   34,
    QMetaType::Void, QMetaType::Bool,   34,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void CNodeEditorUIController::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<CNodeEditorUIController *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->exportFile(); break;
        case 1: _t->exportPDF(); break;
        case 2: _t->exportSVG(); break;
        case 3: _t->exportDOT(); break;
        case 4: { bool _r = _t->importCSV((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< QString*(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 5: _t->doBackup(); break;
        case 6: _t->onNavigatorShown(); break;
        case 7: _t->onSelectionChanged(); break;
        case 8: _t->onSceneChanged(); break;
        case 9: _t->onSceneHint((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 10: _t->onSceneStatusChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->onSceneDoubleClicked((*reinterpret_cast< QGraphicsSceneMouseEvent*(*)>(_a[1])),(*reinterpret_cast< QGraphicsItem*(*)>(_a[2]))); break;
        case 12: _t->sceneEditMode((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 13: _t->onEditModeChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->onZoomChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 15: _t->zoom(); break;
        case 16: _t->unzoom(); break;
        case 17: _t->resetZoom(); break;
        case 18: _t->sceneOptions(); break;
        case 19: _t->showNodeIds((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 20: _t->showEdgeIds((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 21: _t->undo(); break;
        case 22: _t->redo(); break;
        case 23: _t->changeItemId(); break;
        case 24: _t->addNodePort(); break;
        case 25: _t->editNodePort(); break;
        case 26: _t->factorNodes(); break;
        case 27: _t->find(); break;
        case 28: _t->onLayoutFinished(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 11:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QGraphicsItem* >(); break;
            }
            break;
        case 12:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QAction* >(); break;
            }
            break;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject CNodeEditorUIController::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CNodeEditorUIController.data,
    qt_meta_data_CNodeEditorUIController,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *CNodeEditorUIController::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CNodeEditorUIController::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CNodeEditorUIController.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int CNodeEditorUIController::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 29)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 29;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 29)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 29;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
