/****************************************************************************
** Meta object code from reading C++ file 'CCommutationTable.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../CCommutationTable.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'CCommutationTable.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_CCommutationTable_t {
    QByteArrayData data[14];
    char stringdata0[240];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CCommutationTable_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CCommutationTable_t qt_meta_stringdata_CCommutationTable = {
    {
QT_MOC_LITERAL(0, 0, 17), // "CCommutationTable"
QT_MOC_LITERAL(1, 18, 14), // "onSceneChanged"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 18), // "onSelectionChanged"
QT_MOC_LITERAL(4, 53, 29), // "on_Table_itemSelectionChanged"
QT_MOC_LITERAL(5, 83, 26), // "on_Table_itemDoubleClicked"
QT_MOC_LITERAL(6, 110, 16), // "QTreeWidgetItem*"
QT_MOC_LITERAL(7, 127, 4), // "item"
QT_MOC_LITERAL(8, 132, 6), // "column"
QT_MOC_LITERAL(9, 139, 19), // "onCustomContextMenu"
QT_MOC_LITERAL(10, 159, 12), // "onAddSection"
QT_MOC_LITERAL(11, 172, 15), // "onRemoveSection"
QT_MOC_LITERAL(12, 188, 26), // "on_AddColumnButton_clicked"
QT_MOC_LITERAL(13, 215, 24) // "on_RestoreButton_clicked"

    },
    "CCommutationTable\0onSceneChanged\0\0"
    "onSelectionChanged\0on_Table_itemSelectionChanged\0"
    "on_Table_itemDoubleClicked\0QTreeWidgetItem*\0"
    "item\0column\0onCustomContextMenu\0"
    "onAddSection\0onRemoveSection\0"
    "on_AddColumnButton_clicked\0"
    "on_RestoreButton_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CCommutationTable[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   59,    2, 0x09 /* Protected */,
       3,    0,   60,    2, 0x09 /* Protected */,
       4,    0,   61,    2, 0x09 /* Protected */,
       5,    2,   62,    2, 0x09 /* Protected */,
       9,    1,   67,    2, 0x09 /* Protected */,
      10,    0,   70,    2, 0x09 /* Protected */,
      11,    0,   71,    2, 0x09 /* Protected */,
      12,    0,   72,    2, 0x09 /* Protected */,
      13,    0,   73,    2, 0x09 /* Protected */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 6, QMetaType::Int,    7,    8,
    QMetaType::Void, QMetaType::QPoint,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void CCommutationTable::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<CCommutationTable *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->onSceneChanged(); break;
        case 1: _t->onSelectionChanged(); break;
        case 2: _t->on_Table_itemSelectionChanged(); break;
        case 3: _t->on_Table_itemDoubleClicked((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 4: _t->onCustomContextMenu((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 5: _t->onAddSection(); break;
        case 6: _t->onRemoveSection(); break;
        case 7: _t->on_AddColumnButton_clicked(); break;
        case 8: _t->on_RestoreButton_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject CCommutationTable::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_CCommutationTable.data,
    qt_meta_data_CCommutationTable,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *CCommutationTable::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CCommutationTable::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CCommutationTable.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int CCommutationTable::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 9;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
